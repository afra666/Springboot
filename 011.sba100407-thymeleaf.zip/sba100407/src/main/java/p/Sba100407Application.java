package p;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sba100407Application {

    public static void main(String[] args) {
        SpringApplication.run(Sba100407Application.class, args);
    }

}
